import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiadminService } from '../../services/apiadmin.service';
import { Admin } from '../../Admin';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  invalid: string = "";
  ausername: any;
  apassword: string;
  adminData: Admin | null = null;

  aLogin: FormGroup = this.fb.group({
    ausername: ['', [Validators.required]],
    apassword: ['', [Validators.required]],
  });

  constructor(private router: Router, private adminService: ApiadminService, private fb: FormBuilder) { }

  ngOnInit(): void {
  }

  loginAdmin() {
    if (this.aLogin.valid) {
      const formValue = this.aLogin.value;
      this.ausername = formValue.ausername;
      this.apassword = formValue.apassword;

      this.adminService.adminLogin({ username: this.ausername, password: this.apassword }).subscribe(
        (res: Admin) => {
          this.adminData = res;

          if (this.adminData) {
        
            if (this.adminData.password === this.apassword) {
              this.router.navigate(['/admindash']);
              sessionStorage.setItem("AdminId", this.adminData.id.toString());
              sessionStorage.setItem("AdminName", this.adminData.username);
            } else {
              this.invalid = "Invalid Username or Password";
            }
            
          } else {
            this.invalid = "Invalid Username or Password";
          }
        },
        (error) => {
          console.error("Error during admin login:", error);
          this.invalid = "An error occurred during login";
        }
      );
    }
    
  }
}
